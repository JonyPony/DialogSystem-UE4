
title: DialogueSystem
created at: Thu Jul 08 2021 18:56:16 GMT+0000 (Coordinated Universal Time)
updated at: Thu Jul 08 2021 18:56:24 GMT+0000 (Coordinated Universal Time)
---

# DialogueSystem

Система для визуального создания диалогов.

**Редактор**:

![изображение.png](media_DialogueSystem/%D0%B8%D0%B7%D0%BE%D0%B1%D1%80%D0%B0%D0%B6%D0%B5%D0%BD%D0%B8%D0%B5.png)

![Снимок экрана (133).png](media_DialogueSystem/%D0%A1%D0%BD%D0%B8%D0%BC%D0%BE%D0%BA%20%D1%8D%D0%BA%D1%80%D0%B0%D0%BD%D0%B0%20(133).png)

**Настройка диалога.**

![Снимок экрана (137).png](media_DialogueSystem/%D0%A1%D0%BD%D0%B8%D0%BC%D0%BE%D0%BA%20%D1%8D%D0%BA%D1%80%D0%B0%D0%BD%D0%B0%20(137).png)

<mark>_Participants _</mark>– имена участников в рамках только этого диалога. В других могут быть свои. Это как идентификаторы, ячейки ролей. None – везде запрещен для использования

<mark>_Role priority_</mark> – значение роли для этого диалога. Чем выше приоритет, тем быстрее роль будет занята

<mark>_CanBeChosedBy _</mark>– уже реальные никнеймы персонажей(их имена прописываются в компонентя диалога), которые могут занять эту роль

<mark>_Can Join to dialog after start_</mark> – может ли подключиться к диалогу после его начала

<mark>_Can leave from dialog_</mark> – может ли покинуть диалог во время его исполнения

<mark>_IsNecessaryForStart _</mark>– необходима ли эта роль для начала диалога

<mark>_EndDialogWhenLeave _</mark>- диалог закончится сразу после выхода этого участника

<mark>_RoleVisualization _</mark>– настройки графического представления роли в диалоге(только в редакторе)

![Снимок экрана (134).png](media_DialogueSystem/%D0%A1%D0%BD%D0%B8%D0%BC%D0%BE%D0%BA%20%D1%8D%D0%BA%D1%80%D0%B0%D0%BD%D0%B0%20(134).png)

Rebuild – полностью пересобирает диалог

GenerateEndNodesOnLeafs – генерировать ноды окончания диалога на концах веток.

**Ноды**

![Снимок экрана (135).png](media_DialogueSystem/%D0%A1%D0%BD%D0%B8%D0%BC%D0%BE%D0%BA%20%D1%8D%D0%BA%D1%80%D0%B0%D0%BD%D0%B0%20(135).png)

<mark>_Root _</mark>– корень. Его не возможно удалить

<mark>_Selector _</mark>– выбирает следующее действие по условию

<mark>_End _</mark>– завершает диалог

<mark>_Send Event_</mark> – генерирует событие

_Say _– сказать фразу

При нажатии на ноду открывается подробная информация о ней

При нажатии на пустое место — информация об этом диалоге

![изображение.png](media_DialogueSystem/2224e09c-6926-4496-9423-f47a6807875a_%D0%B8%D0%B7%D0%BE%D0%B1%D1%80%D0%B0%D0%B6%D0%B5%D0%BD%D0%B8%D0%B5.png)

participants names - список ролей, которым будет отправлено события при соблюдении условия SendEventOption

![Снимок экрана (136).png](media_DialogueSystem/%D0%A1%D0%BD%D0%B8%D0%BC%D0%BE%D0%BA%20%D1%8D%D0%BA%D1%80%D0%B0%D0%BD%D0%B0%20(136).png)

<mark>_Who say_</mark> – имя роли, которая будет говорить

<mark>_Shorted phrase_</mark> - сокращенная фраза. Та, что буде отображаться при выборе ответа

<mark>_Phrase _</mark>– полный текст фразы(локализуемый движком. Писать на одном языке)

<mark>_Phrase sound_</mark> – озвучка. Может и не быть. Субтитры в настройке звукового файла

<mark>_Phrase propagation_</mark> – распространение фразы

<mark>_ParticipantsNames _</mark>– имена ролей, которым адрисована фраза при соблюдении Say Option.

Т.е бот поймет, что это ему сказали. Если он не указан, то он все равно услышит, просто не воспримет в свой адрес.

**Условие перехода между нодами.**

![изображение.png](media_DialogueSystem/f179378b-9057-4c5f-a3e7-9570a878bba5_%D0%B8%D0%B7%D0%BE%D0%B1%D1%80%D0%B0%D0%B6%D0%B5%D0%BD%D0%B8%D0%B5.png)

* * *

NeedToBeChosedBy – Если не None, то будет отправлен запрос на выбор самому агенту. Если это игрок, то ему будет предоставлен выбор.

Condition – условие перехода.

### **Эвенты, условия и PhrasePropagetion пишутся кастомно, наследуясь от базовых классов.**

          